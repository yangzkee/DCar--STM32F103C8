MG520 固件更新 — 2026-05-27
============================

文件:
  firmware.bin   — 烧录用二进制
  firmware.hex   — 烧录用 hex (推荐)

烧录方式 (保留 sector 1/2 用户参数 + IMU 校准):
  pyocd flash -t stm32f407vetx -f 4000000 --trust-crc firmware.hex

注意: 切勿使用 mass erase, 会丢失校准数据。
